

# Autonomus Drone Navigation for Surveillance Environment

### Environments
This repository contains the implementation of Gym environment for the drone navigation in surveillance environment by [dtungpka](https://github.com/dtungpka)


### Wrappers
> TBA