from setuptools import setup

setup(
    name="drone-surveillance-dtungpka",
    version="1.0.2",
    install_requires=["gym==0.26.2", "pygame==2.5.2"],
)
