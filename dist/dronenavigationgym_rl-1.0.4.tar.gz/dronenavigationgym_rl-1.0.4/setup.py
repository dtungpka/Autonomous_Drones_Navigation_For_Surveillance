from setuptools import setup

setup(
    name="drone-surveillance-dtungpka",
    version="1.0.4",
    install_requires=["gymnasium","numpy","pygame"],
)
